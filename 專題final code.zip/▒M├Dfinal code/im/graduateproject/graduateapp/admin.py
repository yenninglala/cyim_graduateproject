from django.contrib import admin

from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
# from .models import UserProfile
from graduateapp.models import managepeople, QA, UserProfile

admin.site.unregister(User)


class UserProfileInline(admin.StackedInline):
    model = UserProfile


class UserProfileAdmin(UserAdmin):
    inlines = [UserProfileInline, ]


admin.site.register(User, UserProfileAdmin)



class manageadmin(admin.ModelAdmin):
    list_display = ('id', 'cName', 'cNum', 'cPassword', 'cEmail', 'cPoisition')
    # list_filter = ('cName', 'cNum')
    # search_fields = ('cName', 'cNum', 'cPoisition',)
    ordering = ('id',)
    
admin.site.register(managepeople, manageadmin)


class QAadmin(admin.ModelAdmin):
    list_display = ('id', 'QUESTION', 'ANSWER', 'KEYWORD', 'GROUP')
    # list_filter = ('QUESTION', 'KEYWORD', 'GROUP')
    # search_fields = ('QUESTION', 'ANSWER', 'KEYWORD', 'GROUP',)
    ordering = ('id',)

admin.site.register(QA, QAadmin)

