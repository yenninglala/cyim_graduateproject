from django.apps import AppConfig


class GraduateappConfig(AppConfig):
    name = 'graduateapp'
