from django import forms
from .models import QA, managepeople
import django_filters


class ManagerFilter(django_filters.FilterSet):
    cName = django_filters.CharFilter(
        lookup_expr='icontains',
        widget=forms.TextInput(attrs={'class': 'form-control small', 'placeholder': "請輸入姓名做查詢"}))
    cPoisition = django_filters.CharFilter(
        widget=forms.Select(choices=(('', '顯示'),) + managepeople.items, attrs={'class': 'btn btn-secondary dropdown-toggle'}))

    class Meta:
        model = managepeople
        fields = '__all__'


class ReviewFilter(django_filters.FilterSet):
    QUESTION = django_filters.CharFilter(
        lookup_expr='icontains',
        widget=forms.TextInput(attrs={'class': 'form-control small mb-1', 'placeholder': "問題"}))

    ANSWER = django_filters.CharFilter(
        lookup_expr='icontains',
        widget=forms.TextInput(attrs={'class': 'form-control small mb-1', 'placeholder': "答案"}))

    KEYWORD = django_filters.CharFilter(
        lookup_expr='icontains',
        widget=forms.TextInput(attrs={'class': 'form-control small mb-1', 'placeholder': "關鍵字"}))

    class Meta:
        model = QA
        fields = '__all__'
