from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,
                                related_name='profile')
    # 模型類中設定:blank=True,表示程式碼中建立資料庫記錄時該欄位可傳空白(空串,空字串)
    org = models.CharField('Organization', max_length=128, blank=True) # 使用者名稱
    telephone = models.CharField('Telephone', max_length=50, blank=True)
    mod_data = models.DateTimeField('Last modified', auto_now=True)  # mod_date: 最後修改日期。系統自動生成

    class Meta:
        verbose_name = 'User profile'

    def __str__(self):
        # return self.user.__str__()
        return "{}".format(self.user.__str__())

# Create your models here.

class managepeople(models.Model):
    items = (
        ('MANAGER', 'MANAGER'), 
        ('EMPLOYEE', 'EMPLOYEE'),
        )
    cPoisition = models.CharField(max_length=20, null=False, choices=items,)
    cName = models.CharField(max_length=20, null=False)
    cNum = models.CharField(max_length=20, null=False)
    cPassword = models.CharField(max_length=20, null=False)
    cEmail = models.EmailField(max_length=200, null=False)
   
    def __str__(self):
        return self.cName


class QA(models.Model):
    QAitems = (
        ('全校', '全校'), 
        ('系上', '系上'), 
        ('其他', '其他')
    )
    GROUP = models.CharField(max_length=20, null=False,default='全校', choices=QAitems,)
    QUESTION = models.CharField(max_length=50, null=False)
    ANSWER = models.CharField(max_length=200, null=False)
    KEYWORD = models.CharField(max_length=50, null=True)


    # def __str__(self):
    #     return self.QUESTION