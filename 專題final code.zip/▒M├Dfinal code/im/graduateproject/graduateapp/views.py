from django.shortcuts import render, redirect
from django.contrib.auth import authenticate
from django.contrib import auth
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import User
from graduateapp.models import managepeople, QA
from graduateapp.filters import ReviewFilter, ManagerFilter
from django.template import loader


# Create your views here.

def login(request):
    if request.session.get('is_login', None):
        return redirect('logout')

    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        if username and password:  # 确保用户名和密码都不为空
            username = username.strip()
            try:
                # manager = managepeople.objects.all()
                if managepeople.objects.filter(cNum=username, cPassword=password).exists():
                    unit = managepeople.objects.get(
                        cNum=username, cPassword=password)
                    request.session['is_login'] = True
                    request.session['user_id'] = unit.cNum
                    request.session['user_name'] = unit.cName
                    request.session['user_p'] = unit.cPoisition

                    message = '登入成功！'
                    # 登入成功產生一個 Session，重導到<index.html>
                    return redirect('index')
                else:
                    message = '登入失敗！'

            except:
                message = "ERROR！"
        else:
            message = "請輸入正確的帳號密碼！"

    return render(request, "login.html", locals())  # 登入失敗則重導回<login.html>

def logout(request):
    if not request.session.get('is_login', None):
        # 如果本来就未登录，也就没有登出一说
        return redirect('login')
    request.session.flush()
    # auth.logout(request)  # 登出成功清除 Session，重導到<login.html>
    return redirect('login')

def index(request):
    if request.session.get('is_login'):
        return render(request, "index.html", locals())
        
    if request.session.get('is_login', None):
        message = '請登入'
        return redirect('login')
        
    return redirect('logout')

def review(request):
    if request.session.get('is_login'):
        QAs = QA.objects.all().order_by('id')

        reviewFilter = ReviewFilter(queryset=QAs)

        if request.method == "POST":
            reviewFilter = ReviewFilter(request.POST, queryset=QAs)

        context = {
            'reviewFilter': reviewFilter
        }

        return render(request, "review.html", context)
    else:
        message = "請重新登入"
    return redirect('logout')

def manage(request):
    if request.session.get('is_login'):
        manages = managepeople.objects.all().order_by('id')
        
        managerFilter = ManagerFilter(queryset=manages)

        if request.method == "POST":
            managerFilter = ManagerFilter(request.POST, queryset=manages)

        context = {
            'managerFilter': managerFilter
        }

        return render(request, "manage.html", context)
    else:
        message = "請重新登入"
    return redirect('logout')

def deletemanager(request, cNum=None):  # 刪除資料
    # if id != None:
    message = ""
    if request.method == "POST":  # 如果是以POST的分是才處理
        cnum = request.POST['cnum']  # 取得表單輸入的編號
    try:
        unit = managepeople.objects.filter(cNum=cnum)  # 取得學號欄位的資料
        unit.delete()  # 刪除資料
        return redirect('manage')
    except:
        message = "讀取錯誤!"
    return render(request, "manage.html", locals())

def editmanager(request):
    if request.method == "POST":  
        cNum = request.POST['cNum']
        if managepeople.objects.filter(cNum=cNum).exists():
            unit = managepeople.objects.get(cNum=cNum)  # 取得要修改的資料紀錄
        else:
            message = "此 編碼 不存在!"

    elif request.method == "GET": # 如果是由<edit.html>按submit
        cName = request.GET['cName']
        if managepeople.objects.filter(cName=cName).exists():
            unit = managepeople.objects.get(cName=cName)# 取得表單輸入資料
            unit.cEmail = request.GET['cEmail']
            unit.cPoisition = request.GET['cPoisition']
            unit.save()
            message = "已修改"
            return redirect('manage')
    else:
        message = '未傳出資料'
    return render(request, "editmanager.html", locals())

def addmanager(request):  # 新增管理員
    manages = managepeople.objects.all().order_by('id')

    if request.method == "POST":
        cNum = request.POST['cNum']

        if managepeople.objects.filter(cNum=cNum).exists():
            message = '已有帳號，不得重複新增'
        else:
            cName = request.POST['cName']
            cPassword = request.POST['cPassword']
            cEmail = request.POST['cEmail']
            cPoisition = request.POST['cPoisition']
            unit = managepeople.objects.create(
                cName=cName, cNum=cNum, cPassword=cPassword, cEmail=cEmail, cPoisition=cPoisition)
            unit.save()
            message = "已儲存"
        return redirect('manage')
    else:
        message = "請輸入正確資料"
    return render(request, "manage.html", locals())

def addQA(request):  # 新增管理員
    QAs = QA.objects.all().order_by('id')

    if request.method == "POST":
        QUESTION = request.POST['QUESTION']
        GROUP = request.POST['GROUP']
        ANSWER = request.POST['ANSWER']
        KEYWORD = request.POST['KEYWORD']
        unit = QA.objects.create(
            QUESTION=QUESTION, GROUP=GROUP, ANSWER=ANSWER, KEYWORD=KEYWORD)
        unit.save()
        message = "已儲存"
        return redirect('review')
    else:
        message = "請輸入正確資料"
    return render(request, "review.html", locals())

def deleteQA(request, QUESTION=None):  # 刪除資料
    # if id != None:
    message = ""
    if request.method == "POST":  # 如果是以POST的分是才處理
        QUESTION = request.POST['QUESTION']  # 取得表單輸入的編號
    try:
        unit = QA.objects.filter(QUESTION=QUESTION)  # 取得學號欄位的資料
        unit.delete()  # 刪除資料
        return redirect('review')
    except:
        message = "讀取錯誤!"
    return render(request, "review.html", locals())

def editQA(request, QUESTION=None):  # 編輯資料
    if request.method == "POST":  
        QUESTION = request.POST['QUESTION']
        if QA.objects.filter(QUESTION=QUESTION).exists():
            unit = QA.objects.get(QUESTION=QUESTION)  # 取得要修改的資料紀錄
        else:
            message = "此 id 不存在!"

    elif request.method == "GET": # 如果是由<edit.html>按submit
        QUESTION = request.GET['QUESTION']
        if QA.objects.filter(QUESTION=QUESTION).exists():
            unit = QA.objects.get(QUESTION=QUESTION)# 取得表單輸入資料
            unit.GROUP = request.GET['GROUP']
            unit.ANSWER = request.GET['ANSWER']
            unit.KEYWORD = request.GET['KEYWORD']
            unit.save()
            message = "已修改"
            return redirect('review')
        
    else:
        message = '未傳出資料'
    return render(request, "editreview.html", locals())

def register(request):
    return render(request, "register.html", locals())

def forgot(request):
    return render(request, "forgot-password.html", locals())

def resetpassword(request):
    if request.method == "POST":  
        cNum = request.POST['cNum']
        cPassword = request.POST['cPassword']
        newPsd = request.POST['newPsd']
        checkPsd = request.POST['checkPsd']
        if newPsd == checkPsd:
            if managepeople.objects.filter(cNum=cNum,cPassword=cPassword).exists():
                unit = managepeople.objects.get(cNum=cNum)  # 取得要修改的資料紀錄
                unit.cPassword = newPsd
                unit.save()
                message = '成功修改'
                return redirect('resetpassword')
            else:
                message = '修改失敗'
        else:
            message = '新密碼不一致'
    return render(request, "resetpassword.html", locals())
