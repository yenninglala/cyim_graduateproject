"""graduateproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.urls import path, re_path, include
from django.contrib import admin
from graduateapp import views

urlpatterns = [
    #url(r'^review_Search/$', views.review_Search),
    # url(r'^review_Search', views.review_Search,name='review_Search'),
    
    #用于与ajax交互
    # re_path(r'^review_Search/$',views.review_Search,name='review_Search'),
    path('',include([
        path('admin/', admin.site.urls),
        path('',views.login,name='login'),
        path(r'^logout$',views.logout,name='logout'),
        path(r'^index$',views.index,name='index'),
        path(r'^review$',views.review,name='review'), 
        path(r'^manage$',views.manage,name='manage'),
        path(r'^forgot$',views.forgot,name='forgot'),
        path(r'^register$',views.register,name='register'),
        path('addmanager/', views.addmanager, name='addmanager'),
        path('deletemanager/', views.deletemanager, name='deletemanager'),
        path('editmanager/', views.editmanager, name='editmanager'),
        path('addQA/', views.addQA, name='addQA'),
        path('deleteQA/', views.deleteQA, name='deleteQA'),
        path('editQA/', views.editQA, name='editQA'),
        path(r'^resetpassword$',views.resetpassword,name='resetpassword'),
    ]))
]   