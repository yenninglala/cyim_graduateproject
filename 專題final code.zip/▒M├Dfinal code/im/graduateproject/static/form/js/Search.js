$(function () {
    $('#Btn-Search').on('click', function (e) {
        var search = $('#Input-Search').val();
        //var Q = $('#Q').html();

        if (search == "") {
            alert("請輸入內容");
        }
        else {
            //alert("什麼");
            GetSearch(search);
        }
    });
});

function GetSearch(search) {
    $.ajax({
        type: 'POST',
        url: '/review_Search/',
        data: { //傳遞參數
            'SEARCH': search 
        }, 
        dataType: "JSON", //傳送格式
        success: function (data) {
            DoData(data);
        },
        error: function (e) {
            alert("Error:" + XMLHttpRequest.readyState + XMLHttpRequest.status + XMLHttpRequest.responseText);
        }
    })
}

function DoData(data) {
    //清空Table
    $('#Table-QA tbody').html('');
    if (data.STATUS == "True") {
        $.each(data.CONTENT, function (index, val) {
            try {
                var temHtml = '<tr>' +
                    '<td>Q</td>' +
                    '<td>'+ val[0] +'</td>' +
                    // '<td>'+ val.ANSWER +'</td>' +
                    '<td><button class="btn_edit btn wordy mx-2">修改</button><button class="btn_delete btn wordy">刪除</button></td>' +
                    '</tr>';

                $("#Table-QA tbody").append(temHtml);
            }
            catch (err) {
                alert("異常錯誤： [取]" + err.toString());
            }
        });
    }
    else {
        alert("Error:" + data.message);
    }

}